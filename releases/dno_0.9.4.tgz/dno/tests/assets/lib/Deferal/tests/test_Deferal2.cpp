/*
 * Same tests as test_Deferal.cpp except that our test class is now
 * called DeferalNT, and it has no optional timer function (uses
 * millis() only).
 */
#include "cppunit.h"

#define DEFERAL_MINIMAL
#define DEFERAL_CLASS DeferalNT
#define DEFERAL_CALLBACK
#define DEFERAL_AUTOREPEAT
#include "Deferal.cpp"

extern  unsigned long milli_count;

static int counter = 0;

static void
endDelay(void *ignore)
{
    counter++;
}
    

class Cppunit_tests2: public Cppunit
{
    
    /**
     * Run the reduced set of unit tests for deferals without timer_fn()
     */

    /* Test a single Deferal with simple delays. */
    void
    test_single_delay()
    {
	// TEST: Run 200 unit delay.  Check it is not done until 200
	// units have passed, and that it then stays done.
	milli_count = 1000;
	DeferalNT delay1(200);
	
	// Not done until milli_count reaches 1200
        CHECKT(!delay1.stopped());
	milli_count = 1100;
        CHECKT(!delay1.stopped());
	milli_count = 1200;
        CHECKT(delay1.stopped());
	milli_count = 1300;
        CHECKT(delay1.stopped());

	// TEST: Restart the delay using again().  Check it is not
	// done until 200 units have passed.
	delay1.again();
        CHECKT(!delay1.stopped());
	milli_count = 1400;
        CHECKT(delay1.stopped());
	milli_count = 1500;
        CHECKT((delay1.status() == DEFERAL_STOPPED));

	// TEST: Restart the delay using again(), and then reset it
	// using start().  Check it is not done until 200 units have
	// passed from start().  Use checkDeferals() to expire the
	// Deferal and test that it returns the expected results.
	delay1.again();
	milli_count = 1550;
        CHECKT(!delay1.stopped());
	delay1.start();
	milli_count = 1749;
	CHECKT(!delay1.stopped());

	//Ensure checkDeferals() returns nothing if there are
	// no newly expired Deferals.
	CHECKP(DeferalNT::checkDeferals(), NULL);
	milli_count = 1750;
	// Expiry of delay1 Should only be reported once
	CHECKP(DeferalNT::checkDeferals(), &delay1);  
	CHECKP(DeferalNT::checkDeferals(), NULL);
        CHECKT(delay1.stopped());
	CHECKP(DeferalNT::checkDeferals(), NULL);
    }

    /* Test a single Deferal with simple delays. */
    void
    test_autorepeat()
    {
	// TEST: Run 200 unit delay.  Check it is not done until 200
	// units have passed, and that it then stays done.
	milli_count = 1000;
	counter = 0;
	DeferalNT autodelay(200, endDelay, NULL, true);
	
	milli_count = 1250;
	// The expired Deferal is reported even though it has been
	// automatically restarted.
	CHECKP(DeferalNT::checkDeferals(), (void *) &autodelay);
        CHECKT(counter == 1);
	milli_count = 1450;
	CHECKT(!autodelay.stopped());
	CHECKT(autodelay.running());
        CHECKT(counter == 2);
	milli_count = 2050;
	CHECKT(!autodelay.stopped());
        CHECK(counter, 5);
	CHECKT(autodelay.status() == DEFERAL_RUNNING);
        CHECK(counter, 5);
    }
    
    void
    test_pause()
    {
	// TEST: Check that pause() and resume() do as expected.
	milli_count = 1000;
	DeferalNT pausedelay(200);
	CHECKT(!pausedelay.stopped());
	CHECKT(!pausedelay.paused());
	CHECKT(pausedelay.running());
	milli_count = 1050;
	pausedelay.pause();
	CHECKT(pausedelay.paused());
	milli_count = 1400;
	CHECKT(pausedelay.paused());
	pausedelay.resume();
	CHECKT(pausedelay.running());
	milli_count = 1549;
	CHECKT(pausedelay.running());
	milli_count = 1550;
	CHECKT(pausedelay.stopped());
	pausedelay.pause();
	CHECKT(pausedelay.stopped());
    }
    
    // Multiple delays, and constructor/destructor tests.
    void
    test_multiple_delays()
    {
	milli_count = 1000;
	DeferalNT delay1(200);
	DeferalNT *delay2 = new DeferalNT(200);
	DeferalNT delay3(200);
	
	// Delays will be complete at milli_count = 1200
        CHECKT(!delay1.stopped());
	CHECK(delay1.remaining(), 200);
        CHECKT(!delay2->stopped());
        CHECKT(!delay3.stopped());
	milli_count = 1200;
	CHECK(delay1.remaining(), 0);
	CHECKP(DeferalNT::checkDeferals(), &delay1);  
	CHECKP(DeferalNT::checkDeferals(), delay2);  
	CHECKP(DeferalNT::checkDeferals(), &delay3);  
	CHECKP(DeferalNT::checkDeferals(), NULL);
        CHECKT(delay1.stopped());
        CHECKT(delay2->stopped());
        CHECKT(delay3.stopped());

	// Run all 3 delays again (restarting in different order).
	delay1.again();
	delay3.again();
	delay2->again();
	// Delays will be complete at milli_count = 1400
	CHECKP(DeferalNT::checkDeferals(), NULL);
	milli_count = 1500;
	CHECKP(DeferalNT::checkDeferals(), &delay1);  
	CHECKP(DeferalNT::checkDeferals(), &delay3);  
	CHECKP(DeferalNT::checkDeferals(), delay2);  
	CHECKP(DeferalNT::checkDeferals(), NULL);

	// Run 2 delays again.
	delay1.again();
	delay2->again();
	// Delays will be complete at milli_count = 1600
	CHECKP(DeferalNT::checkDeferals(), NULL);
	milli_count = 1650;
	CHECKP(DeferalNT::checkDeferals(), &delay1);  
	CHECKP(DeferalNT::checkDeferals(), delay2);  
	CHECKP(DeferalNT::checkDeferals(), NULL);

	CHECK(delay3.remaining(), -250);
	delay3.again();
	CHECK(delay3.remaining(), -50);
	delay3.again();
	CHECK(delay3.remaining(), 150);
	CHECKP(DeferalNT::checkDeferals(), NULL);

	// Now we start them again, and delete delay2
	delay1.again();
	CHECK(delay1.remaining(), 150);
	delay2->again();
	CHECK(delay2->remaining(), 150);
	CHECK(delay3.remaining(), 150);
	// Delays will be complete at milli_count = 1800
	
	delete delay2;
	CHECKP(DeferalNT::checkDeferals(), NULL);
	milli_count = 1820;
	CHECK(delay3.remaining(), -20);
	CHECK(delay1.remaining(), -20);

	CHECKP(DeferalNT::checkDeferals(), &delay3);  
	CHECKP(DeferalNT::checkDeferals(), &delay1);  
	CHECKP(DeferalNT::checkDeferals(), NULL);

	delay1.again();
	delay3.again();
	{
	    DeferalNT delay4(200);
	    milli_count = 1999;
	    CHECK(delay1.remaining(), 1);
	    CHECK(delay3.remaining(), 1);
	    CHECK(delay4.remaining(), 21);
	    CHECKP(DeferalNT::checkDeferals(), NULL);
	    milli_count = 2001;
	    CHECKP(DeferalNT::checkDeferals(), &delay1);
	    CHECKP(DeferalNT::checkDeferals(), &delay3);
	    CHECKP(DeferalNT::checkDeferals(), NULL);
	    milli_count = 2020;
	    CHECKP(DeferalNT::checkDeferals(), &delay4);
	    // And again, but we will close this block, thereby
	    // deleting delay4
	    delay1.again();
	    delay4.again();
	    delay3.again();
	    // Delays will be complete at milli_count = 2200
	    CHECKP(DeferalNT::checkDeferals(), NULL);
	}
	milli_count = 2200;
	CHECKP(DeferalNT::checkDeferals(), &delay1);
	delay3.stop();
	CHECKP(DeferalNT::checkDeferals(), NULL);
    }    

    void
    test_deferal_fn()
    {
	milli_count = 1000;
	counter = 0;
	DeferalNT delay(200, endDelay, NULL, true);
	milli_count = 1250;
	CHECKP(DeferalNT::checkDeferals(), &delay);
        CHECKT(counter == 1);
	delay.setDeferalFn(NULL);
	milli_count = 1450;
	CHECKP(DeferalNT::checkDeferals(), &delay);
        CHECKT(counter == 1);
	delay.setDeferalFn(endDelay);
	milli_count = 1650;
	CHECKP(DeferalNT::checkDeferals(), &delay);
        CHECKT(counter == 2);
    }

    /**
     * Run the full set of unit tests for Deferals
     */
    void
    test_list()
    {
	test_single_delay();
	test_autorepeat();
	test_pause();
	test_multiple_delays();
	test_deferal_fn();
    }

};

extern int tests2();

int
tests2()
{
    printf("\nCppunit_tests2)->run()    [DeferalNT]\n");
    return (new Cppunit_tests2)->run();
}
