/*
 * Same tests as test_Deferal2.cpp except that our test class is now
 * called DeferalNC, and it has no callback functions.
 */

#include "cppunit.h"

#define DEFERAL_MINIMAL
#define DEFERAL_CLASS DeferalNC
#define DEFERAL_AUTOREPEAT
#include "Deferal.cpp"

extern  unsigned long milli_count;

class Cppunit_tests3: public Cppunit
{
    
    /**
     * Run the reduced set of unit tests for deferals without timer_fn()
     */

    /* Test a single Deferal with simple delays. */
    void
    test_single_delay()
    {
	// TEST: Run 200 unit delay.  Check it is not done until 200
	// units have passed, and that it then stays done.
	milli_count = 1000;
	DeferalNC delay1(200);
	
	// Not done until milli_count reaches 1200
        CHECKT(!delay1.stopped());
	milli_count = 1100;
        CHECKT(!delay1.stopped());
	milli_count = 1200;
        CHECKT(delay1.stopped());
	milli_count = 1300;
        CHECKT(delay1.stopped());

	// TEST: Restart the delay using again().  Check it is not
	// done until 200 units have passed.
	delay1.again();
        CHECKT(!delay1.stopped());
	milli_count = 1400;
        CHECKT(delay1.stopped());
	milli_count = 1500;
        CHECKT((delay1.status() == DEFERAL_STOPPED));

	// TEST: Restart the delay using again(), and then reset it
	// using start().  Check it is not done until 200 units have
	// passed from start().  Use checkDeferals() to expire the
	// Deferal and test that it returns the expected results.
	delay1.again();
	milli_count = 1550;
        CHECKT(!delay1.stopped());
	delay1.start();
	milli_count = 1749;
	CHECKT(!delay1.stopped());

	//Ensure checkDeferals() returns nothing if there are
	// no newly expired Deferals.
	CHECKP(DeferalNC::checkDeferals(), NULL);
	milli_count = 1750;
	// Expiry of delay1 Should only be reported once
	CHECKP(DeferalNC::checkDeferals(), &delay1);  
	CHECKP(DeferalNC::checkDeferals(), NULL);
        CHECKT(delay1.stopped());
	CHECKP(DeferalNC::checkDeferals(), NULL);
    }

    /* Test a single Deferal with simple delays. */
    void
    test_autorepeat()
    {
	// TEST: Run 200 unit delay.  Check it is not done until 200
	// units have passed, and that it then stays done.
	milli_count = 1000;
	DeferalNC autodelay(200, true);
	
	milli_count = 1250;
	// The expired Deferal is reported even though it has been
	// automatically restarted.
	CHECKP(DeferalNC::checkDeferals(), (void *) &autodelay);
	milli_count = 1450;
	CHECKT(!autodelay.stopped());
	CHECKT(autodelay.running());
	milli_count = 2050;
	CHECKT(!autodelay.stopped());
	CHECKT(autodelay.status() == DEFERAL_RUNNING);
    }
    
    void
    test_pause()
    {
	// TEST: Check that pause() and resume() do as expected.
	milli_count = 1000;
	DeferalNC pausedelay(200);
	CHECKT(!pausedelay.stopped());
	CHECKT(!pausedelay.paused());
	CHECKT(pausedelay.running());
	milli_count = 1050;
	pausedelay.pause();
	CHECKT(pausedelay.paused());
	milli_count = 1400;
	CHECKT(pausedelay.paused());
	pausedelay.resume();
	CHECKT(pausedelay.running());
	milli_count = 1549;
	CHECKT(pausedelay.running());
	milli_count = 1550;
	CHECKT(pausedelay.stopped());
	pausedelay.pause();
	CHECKT(pausedelay.stopped());
    }
    
    // Multiple delays, and constructor/destructor tests.
    void
    test_multiple_delays()
    {
	milli_count = 1000;
	DeferalNC delay1(200);
	DeferalNC *delay2 = new DeferalNC(200);
	DeferalNC delay3(200);
	
	// Delays will be complete at milli_count = 1200
        CHECKT(!delay1.stopped());
	CHECK(delay1.remaining(), 200);
        CHECKT(!delay2->stopped());
        CHECKT(!delay3.stopped());
	milli_count = 1200;
	CHECK(delay1.remaining(), 0);
	CHECKP(DeferalNC::checkDeferals(), &delay1);  
	CHECKP(DeferalNC::checkDeferals(), delay2);  
	CHECKP(DeferalNC::checkDeferals(), &delay3);  
	CHECKP(DeferalNC::checkDeferals(), NULL);
        CHECKT(delay1.stopped());
        CHECKT(delay2->stopped());
        CHECKT(delay3.stopped());

	// Run all 3 delays again (restarting in different order).
	delay1.again();
	delay3.again();
	delay2->again();
	// Delays will be complete at milli_count = 1400
	CHECKP(DeferalNC::checkDeferals(), NULL);
	milli_count = 1500;
	CHECKP(DeferalNC::checkDeferals(), &delay1);  
	CHECKP(DeferalNC::checkDeferals(), &delay3);  
	CHECKP(DeferalNC::checkDeferals(), delay2);  
	CHECKP(DeferalNC::checkDeferals(), NULL);

	// Run 2 delays again.
	delay1.again();
	delay2->again();
	// Delays will be complete at milli_count = 1600
	CHECKP(DeferalNC::checkDeferals(), NULL);
	milli_count = 1650;
	CHECKP(DeferalNC::checkDeferals(), &delay1);  
	CHECKP(DeferalNC::checkDeferals(), delay2);  
	CHECKP(DeferalNC::checkDeferals(), NULL);

	CHECK(delay3.remaining(), -250);
	delay3.again();
	CHECK(delay3.remaining(), -50);
	delay3.again();
	CHECK(delay3.remaining(), 150);
	CHECKP(DeferalNC::checkDeferals(), NULL);

	// Now we start them again, and delete delay2
	delay1.again();
	CHECK(delay1.remaining(), 150);
	delay2->again();
	CHECK(delay2->remaining(), 150);
	CHECK(delay3.remaining(), 150);
	// Delays will be complete at milli_count = 1800
	
	delete delay2;
	CHECKP(DeferalNC::checkDeferals(), NULL);
	milli_count = 1820;
	CHECK(delay3.remaining(), -20);
	CHECK(delay1.remaining(), -20);

	CHECKP(DeferalNC::checkDeferals(), &delay3);  
	CHECKP(DeferalNC::checkDeferals(), &delay1);  
	CHECKP(DeferalNC::checkDeferals(), NULL);

	delay1.again();
	delay3.again();
	{
	    DeferalNC delay4(200);
	    milli_count = 1999;
	    CHECK(delay1.remaining(), 1);
	    CHECK(delay3.remaining(), 1);
	    CHECK(delay4.remaining(), 21);
	    CHECKP(DeferalNC::checkDeferals(), NULL);
	    milli_count = 2001;
	    CHECKP(DeferalNC::checkDeferals(), &delay1);
	    CHECKP(DeferalNC::checkDeferals(), &delay3);
	    CHECKP(DeferalNC::checkDeferals(), NULL);
	    milli_count = 2020;
	    CHECKP(DeferalNC::checkDeferals(), &delay4);
	    // And again, but we will close this block, thereby
	    // deleting delay4
	    delay1.again();
	    delay4.again();
	    delay3.again();
	    // Delays will be complete at milli_count = 2200
	    CHECKP(DeferalNC::checkDeferals(), NULL);
	}
	milli_count = 2200;
	CHECKP(DeferalNC::checkDeferals(), &delay1);
	delay3.stop();
	CHECKP(DeferalNC::checkDeferals(), NULL);
    }    

    /**
     * Run the full set of unit tests for Deferals
     */
    void
    test_list()
    {
	test_single_delay();
	test_autorepeat();
	test_pause();
	test_multiple_delays();
    }

};

extern int tests3();

int
tests3()
{
    printf("\nCppunit_tests3)->run()    [DeferalNC]\n");
    return (new Cppunit_tests3)->run();
}
