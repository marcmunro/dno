#define DEFERAL_MINIMAL
#define DEFERAL_CALLBACK
#include <Deferal.cpp>
#include <avr/eeprom.h>

unsigned long millis()
{
    return 0l;
}

// We use EEMEM here in order to isolate the memory used for Deferal
// from anything else.  This should give us a reliable value for the
// size of a Deferal object.
//
static Deferal EEMEM def(200);

#define SIZE_LABEL Minimal Deferal + callbacks(CB)

int
main (int argc, char *argv[])
{
    def.stop();
}
