/**
 * @file   Deferal.h
 * \code
 *     Author:       Marc Munro
 *     Copyright (c) 2024 Marc Munro
 *     License:      GPL V3
 * 
 * \endcode
 * @brief  
 * Defines the Deferal class.
 * 
 */

#ifndef LIB_DEFERAL
#define LIB_DEFERAL

#define DEFERAL_VERSION 0.9.0

#include <Arduino.h>
#include <limits.h>

#ifndef DEFERAL_CLASS
/**
 * @brief Name of our Deferal class.
 *
 * By default this will be "Deferal".  This symbol exists in order to
 * allow different Deferal classes to be defined.  If you need to have
 * multiple types of Deferal, or you are unable, using your chosen Arduino
 * build tool, to provide definitions for #DEFERAL_MINIMAL and
 * friends, you may need to do something like the following:
 *
 * In the files where you want to use Deferals:
 *
 *      . . . 
 *      #define DEFERAL_CLASS MyDeferal
 *      #define DEFERAL_MINIMAL
 *      #include <Deferal.h>
 *      . . . 
 *      // Wherever you want to use a Deferal object refer to it as
 *      // MyDeferal, eg:
 *      static MyDeferal timer(2000);
 *      . . .
 *
 * And in a seperate file:
 *
 *      #define DEFERAL_CLASS MyDeferal
 *      #define DEFERAL_MINIMAL
 *      #include <Deferal.cpp>
 *
 * This file will compile into a minimal implementation of the Deferal
 * class called MyDeferal.  It needs to be given its own name in order
 * to not clash with any load of the standard Deferal library that
 * your build tool will perform.
 *
 * The better way to deal with this is to simply pass the
 * #DEFERAL_CLASS and #DEFERAL_MINIMAL symbol definitions to the
 * compiler via whatever mechanism your build-tools provide.  For
 * [dno](https://github.com/marcmunro/dno) you can do this by
 * redefining CXXFLAGS in a dno.mk file like this:
 *
 *       CXXFLAGS += -D DEFERAL_MINIMAL -D DEFERAL_CLASS=MyDeferal
 */
#define DEFERAL_CLASS Deferal
#endif

/*! \def DEFERAL_MINIMAL
 *
 * @brief If defined, allow conditional compilation of select Deferal
 * functionality. 
 *
 * This definition can be provided to the compiler in order to
 * eliminate certain functionality from the #DEFERAL_CLASS class.
 * This allows #DEFERAL_CLASS objects to be constructed which have a
 * smaller memory and code footprint.  If this symbol is left
 * undefined, the following symbols become defined, providing full
 * functionality:
 * - #DEFERAL_CALLBACK
 * - #DEFERAL_TIMER_FN
 *
 * If you define #DEFERAL_MINIMAL, you will by default get a minimal,
 * less-functional version of the DEFERAL class.  Additional
 * functionality can then be added by additionally defining one or
 * more of the above symbols.
 */ 
#ifndef DEFERAL_MINIMAL

// The following 2 lines are to make Doxygen recognise the
// DEFERAL_MINIMAL symbol without affecting its definition.
#define DEFERAL_MINIMAL
#undef DEFERAL_MINIMAL

/**
 * @brief If defined, allow a custom TimerFn() to be provided to
 * Deferal objects.
 *
 * This symbol is defined by default unless #DEFERAL_MINIMAL has been
 * defined.  If that is defined the #DEFERAL_CLASS class will allow
 * timer functions other than the default millis().  
 * 
 * For 16-bit arduino platforms such as the atmega328, this will use
 * an extra 2 bytes of memory per instance.
 */
#define DEFERAL_TIMER_FN

/**
 * @brief If defined, allow callback functions to be passed to Deferal
 * objects.
 *
 * This symbol is defined by default unless #DEFERAL_MINIMAL has been
 * defined.  If it is defined the #DEFERAL_CLASS class will allow
 * callback functions to be passed to each Deferal instance.  Such
 * callbacks will be called whenever the Deferal's expiry is
 * detected.  
 *
 * For 16-bit arduino platforms such as the atmega328, this will use
 * an extra 4 bytes of memory per instance.
 */
#define DEFERAL_CALLBACK
#endif


#ifdef DEFERAL_TIMER_FN
#define TIMER_FN timer_fn_
#else
#define TIMER_FN millis
#endif

/**
 * @brief Records start or remaining time for a Deferal.
 *
 * Since start_time and remaining are never used within the same
 * deferal state, we combine them into a union to save memory.
 */
typedef union deferal_time_t {
    unsigned long start_time;
    unsigned long remaining;
} deferal_time_t;

/**
 * @brief Function Prototype for functions called on the expiry of a deferal 
 */
typedef void (*PostDeferalFn)(void *);

/**
 * @brief Function Prototype for timer functions.  
 *
 * The default timer function is millis().
 */
typedef unsigned long (*TimerFn)();

/**
 * @brief The status of a Deferal object.
 *
 * If a Deferal is in the DEFERAL_RUNNING state, it will exist in the
 * linked list of running Deferals, Deferal#deferal_list_.
 */
typedef enum {
    DEFERAL_RUNNING = 42,
    DEFERAL_PAUSED,
    DEFERAL_STOPPED,
    DEFERAL_PROCESSING  // Used to prevent unwanted recursion
} deferal_status_t;

/**
 * @brief The state and whether autorepeat is allowed for a Deferal.
 *
 * This is combined into a single byte bit-packed struct in order to
 * reduce the memory footprint of each Deferal.
 *
 */
typedef struct deferal_state_t {
    deferal_status_t status: 7;
    bool autorepeat        : 1;
} deferal_state_t;


/**
 * @class Deferal
 * @brief The Deferal class
 * 
 * A Deferal is an object for handling timeouts and other period-based
 * activities.  Deferals provide non-blocking timed operations that
 * can be single-shot or repetitive.  Multiple Deferals can run
 * simultaneously.  A Deferal may be given a callback function which
 * will be called when it expires.
 *
 * Deferals must be periodically checked by polling for expired
 * Deferals using Deferal::checkDeferals().  This returns the latest
 * unreported expired Deferal.  
 *
 * The basic operations on a Deferal are:
 *  - creation.
 *    The constructors define the delay period, whether to
 *    automatically start, the function to be used to tell the time
 *    (defaulting to millis()) and any function, with parameter, to be
 *    called when the Deferal expires.
 * 
 *  - start 
 *    start() restarts the timer from now.  Optionally resets the
 *    delat period.
 * 
 *  - stop
 *    stop() stops the current deferal, optionally running the expiry
 *    function.
 *    
 *  - pause
 *    pause() stops the current deferal, recording the time remaining.
 * 
 *  - resume
 *    resume() resumes the current deferal, for the period given by the
 *    remaining time after a pause.  Resuming a stopped or running
 *    Deferal does nothing.
 * 
 *  - repeat
 *    again() runs the current deferal with the delay period set as if
 *    the Deferal had immediately restarted after completion.  Ie if
 *    the delay period is 1000, but again() was called 100 ticks after
 *    the Deferal completed, the remaining delay period will be 900.
 *    If the Deferal should have run to completion by now, it will
 *    immediately complete and call any post deferal function.
 * 
 *  - test
 *    running(), paused() stopped() and status() give the current
 *    status of a Deferal in different, obvious, ways.
 * 
 *  - modification
 *    setDeferalFn() sets the function to be run on completion of the
 *    Deferal, setDelay() updates the delay time, causing the Deferal
 *    to stop and the post Deferal function to be called if
 *    appropriate.
 *
 */

class DEFERAL_CLASS {
  public:
    DEFERAL_CLASS(unsigned long delay,
		  bool autorepeat=false,
		  bool start=true
#ifdef DEFERAL_TIMER_FN	    
		  , TimerFn timer_fn = millis
#endif
		  );
#ifdef DEFERAL_CALLBACK
    DEFERAL_CLASS(unsigned long delay,
		  PostDeferalFn fn, void *param = NULL,
		  bool autorepeat=false,
		  bool start=true
#ifdef DEFERAL_TIMER_FN	    
		  , TimerFn timer_fn = millis
#endif
	    );
#endif
    
    ~DEFERAL_CLASS();
    
    static DEFERAL_CLASS *checkDeferals();

#ifdef UNIT_TESTING
    static void clearDeferals();
    void reset(unsigned long delay,
	       bool autorepeat,
	       bool start
#ifdef DEFERAL_TIMER_FN	    
	       , TimerFn timer_fn
#endif
	       );
#endif
    
    void start(unsigned long delay = 0);
    void stop(bool run_post_fn=true, bool allow_repeat=false);
    void pause();
    void resume();
    bool stopped();
    bool paused();
    bool running();
    long remaining();
    long delayPeriod();
    deferal_status_t status();
    void again(unsigned long delay = 0, bool run_post_fn=true);
    void setDeferalFn(PostDeferalFn fn, void *param = NULL);
    void setDelay(unsigned long delay);
    void setOffset(unsigned long offset);
  protected:
    static void addDeferalEntry(DEFERAL_CLASS *entry);
    static void removeDeferalEntry(DEFERAL_CLASS *to_remove);

    static DEFERAL_CLASS *deferal_list_;

    void init(unsigned long delay,
	      bool autorepeat,
	      bool start
#ifdef DEFERAL_TIMER_FN	    
	      , TimerFn timer_fn
#endif
	      );
    bool expired();
    void updateStatus();

    
    /// The time, in timer_fn_() units, that the Deferal last started
    /// to run or, for a paused Deferal, the time it has remaining.
    deferal_time_t dtime_;
    
    /// The time, in timer_fn_() units, that the Deferal is to run for
    /// from Deferal#start_time_
    unsigned long    delay_time_;

    /// The current status of the Deferal.
    deferal_state_t state_;

#ifdef DEFERAL_CALLBACK    
    /// The function to be called when the Deferal expires.  May be
    /// NULL if nothing is to be done (ie expiry is to be handled by
    /// other means).
    PostDeferalFn defer_fn_;
    
    /// The parameter to be passed to Deferal::defer_fn_()
    void * defer_fn_param_;
#endif
    
#ifdef DEFERAL_TIMER_FN	    
    /// The function to be called in order to figure out the progress
    /// of a Deferal.  By default this will be millis().
    TimerFn timer_fn_;
#endif
    
    /// For a running Deferal, this identifies the next Deferal in 
    /// Deferal::deferal_list_.  This will be NULL if we are not
    /// running, or if we are the last Deferal in the list.
    DEFERAL_CLASS *next_; 
    
};

#ifdef UNIT_TESTING
#define INTEGER int
#else
#define INTEGER static int
#endif

INTEGER ulo_cmp(unsigned long x, unsigned long y);


#endif
