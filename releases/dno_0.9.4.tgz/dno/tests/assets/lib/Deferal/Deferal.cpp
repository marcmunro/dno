/**
 * @file   Deferal.cpp
 * \code
 *     Author:       Marc Munro
 *     Copyright (c) 2024 Marc Munro
 *     License:      GPL V3
 * 
 * \endcode
 * @brief  
 * Implements the Deferal class.
 *
 * A Deferal is...
 * 
 */

#include "Deferal.h"

/**
 * @var Deferal::deferal_list_
 * @brief The head of a list of currently running Deferal objects.  
 *
 * This is scanned by the checkDeferred() function.  The next item in
 * the list is given by the \link Deferal::next_ next_ \endlink member
 * of the Deferal object.
 */
DEFERAL_CLASS *DEFERAL_CLASS::deferal_list_ = NULL;


/**
 * @brief Create a new, possibly running, Deferal object.
 *
 * Note that the Deferal for each newly started or restarted delay
 * gets added to our #deferal_list_ list.
 *
 * @param delay  The delay for our deferred operation, based on the
 * units of timer_fn().  This will be the number of milliseconds from
 * now.
 * @param autorepeat  Whether the deferal automatically restarts after
 * it expires.
 * @param start  Whether to start the delay immediately.
 * @param timer_fn  The function to be called to get the current time,
 * in suitable units.  This defaults to millis()
 */
DEFERAL_CLASS::DEFERAL_CLASS(unsigned long delay,
			     bool autorepeat,
			     bool start
#ifdef DEFERAL_TIMER_FN	    
			     , TimerFn timer_fn
#endif
		 )
{
    init(delay,
	 autorepeat,
	 start
#ifdef DEFERAL_TIMER_FN	    
	 , timer_fn
#endif
	 );
}

#ifdef DEFERAL_CALLBACK    
/**
 * @brief Create a new, possibly running, Deferal object, with a
 * function to be called asynchronously when the delay has expired.
 *
 * Note that the Deferal for each newly started or restarted delay
 * gets added to our #deferal_list_ list.
 *
 * @param delay  The delay for our deferred operation, based on the
 * units of timer_fn().  By default, this will be the number of
 * milliseconds from now.
 * @param fn  The function to be called on completion of our delay.
 * @param param  A parameter to be passed to the above function on
 * completion of our delay.
 * @param autorepeat  Whether the deferal automatically restarts after
 * it expires.
 * @param start  Whether the deferal is to be automatically started.
 * @param timer_fn  The function to be called to get the current time,
 * in suitable units.  This defaults to millis()
 */
DEFERAL_CLASS::DEFERAL_CLASS(unsigned long delay,
			     PostDeferalFn fn, void *param,
			     bool autorepeat,
			     bool start
#ifdef DEFERAL_TIMER_FN	    
			     , TimerFn timer_fn
#endif
		 )
{
    init(delay,
	 autorepeat,
	 start
#ifdef DEFERAL_TIMER_FN	    
	 , timer_fn
#endif
	 );
    defer_fn_ = fn;
    defer_fn_param_ = param;
}
#endif

/**
 * @brief Do the donkey-work of setting up a new Deferal for constructors.
 */
void
DEFERAL_CLASS::init(unsigned long delay,
		    bool autorepeat,
		    bool start
#ifdef DEFERAL_TIMER_FN	    
		    , TimerFn timer_fn
#endif
	      )
{
#ifdef DEFERAL_TIMER_FN	    
    timer_fn_ = timer_fn;
#endif
    delay_time_ = delay;
    dtime_.start_time = TIMER_FN();
#ifdef DEFERAL_CALLBACK    
    defer_fn_ = NULL;
    defer_fn_param_ = NULL;
#endif
    next_ = NULL;
    state_.autorepeat = autorepeat;
    if (start) {
	addDeferalEntry(this);
	state_.status = DEFERAL_RUNNING;
    }
    else {
	state_.status = DEFERAL_STOPPED;
    }
}

/**
 * @brief Ensure this Deferal is removed from Deferal#deferal_list_ on
 * destruction. 
 */
DEFERAL_CLASS::~DEFERAL_CLASS()
{
    removeDeferalEntry(this);
}

/**
 * @brief Check whether any deferals have expired.
 * @result An expired Deferal, if one has expired since the last call,
 * else NULL.
 */
DEFERAL_CLASS *
DEFERAL_CLASS::checkDeferals()
{
    DEFERAL_CLASS *entry = deferal_list_;
    while (entry) {
	if (entry->expired()) {
	    /* The stop() method will have removed entry from
	     * deferal_list_, so we don't need to. */
	    entry->stop(true, true);
	    return entry;
	}
	entry = entry->next_;
    }
    return NULL;
    
}
/**
 * @brief Add a Deferal object to our #deferal_list_.
 *
 * Adds the Deferal to the end of the list.  If @p entry is already in
 * #deferal_list_, it does nothing.
 *
 * @param entry The new Deferal, to be added to #deferal_list_
 */
void
DEFERAL_CLASS::addDeferalEntry(DEFERAL_CLASS *entry)
{
    if (deferal_list_) {
	DEFERAL_CLASS *deferal = deferal_list_;
	if (deferal == entry) {
	    return;
	}
	while (deferal->next_) {
	    deferal = deferal->next_;
	}
	deferal->next_ = entry;
    }
    else {
	deferal_list_ = entry;
    }

}

/**
 * @brief Remove a Deferal object from our #deferal_list_.
 * @param to_remove The Deferal to be removed from #deferal_list_
 */
void
DEFERAL_CLASS::removeDeferalEntry(DEFERAL_CLASS *to_remove)
{
    DEFERAL_CLASS **p_entry = &deferal_list_;
    while (*p_entry) {
	if (*p_entry == to_remove) {
	    *p_entry = to_remove->next_;
	    to_remove->next_ = NULL;
	    return;
	}
	p_entry = &((*p_entry)->next_);
    }
}

/**
 * @brief Start a new delay from now.
 * @param delay Optionally set a new delay period.
 */
void
DEFERAL_CLASS::start(unsigned long delay) {
    if (delay) {
	delay_time_ = delay;
    }
    dtime_.start_time = TIMER_FN();
    if (state_.status != DEFERAL_RUNNING) {
	state_.status = DEFERAL_RUNNING;
	addDeferalEntry(this);
    }
}

/**
 * @brief Stop the current delay, possibly running our defer_fn_()
 * @param run_post_fn Whether to run defer_fn_()
 * @param allow_repeat Whether autorepeat should be allowed.
 */
void
DEFERAL_CLASS::stop(bool run_post_fn, bool allow_repeat)
{
    if (state_.status != DEFERAL_STOPPED) {
	state_.status = DEFERAL_STOPPED;
	removeDeferalEntry(this);
#ifdef DEFERAL_CALLBACK
	if (run_post_fn && defer_fn_) {
	    defer_fn_(defer_fn_param_);
	}
#endif
	if (allow_repeat && state_.autorepeat) {
	    again();
	}
    }
}

bool
DEFERAL_CLASS::expired()
{
    if (state_.status == DEFERAL_RUNNING) {
	unsigned long now = TIMER_FN();
	// If (now - start_time) > MAXINT/2 then our start time is in
	// the future.  That's a bid odd but it doesn't mean we have
	// expired.
	if ((now - dtime_.start_time) > (unsigned long) (-1L >> 1)) {
	    return false;
	}
	return ((now - dtime_.start_time) >= delay_time_);
    }
    return false;
}

/**
 * @brief Check the current state of a Deferal, expiring it as needed.
 * 
 * If a Deferal has passed its completion time, it will be stopped,
 * possibly running the expiry function, and possibly automatically
 * restarting it if appropriate.
 */
void
DEFERAL_CLASS::updateStatus()
{
    if (expired()) {
	stop(true, true);
    }
}

/**
 * @brief Predicate: true if the Deferal is in the stopped state.
 */
bool
DEFERAL_CLASS::stopped()
{
    updateStatus();
    return state_.status == DEFERAL_STOPPED;
}

/**
 * @brief Predicate: true if the Deferal is in the running state.
 */
bool
DEFERAL_CLASS::running()
{
    updateStatus();
    return state_.status == DEFERAL_RUNNING;
}

/**
 * @brief Predicate: true if the Deferal is in the paused state.
 */
bool
DEFERAL_CLASS::paused()
{
    updateStatus();
    return state_.status == DEFERAL_PAUSED;
}

/**
 * @brief Return the status of the Deferal (running, paused, stopped).
 */
deferal_status_t
DEFERAL_CLASS::status()
{
    updateStatus();
    return state_.status;
}

/**
 * @brief Pause a running deferal.
 */
void
DEFERAL_CLASS::pause()
{
    updateStatus();
    if (state_.status == DEFERAL_RUNNING) {
	unsigned long now = TIMER_FN();
	state_.status = DEFERAL_PAUSED;
	dtime_.remaining = now - dtime_.start_time;
    }
}

/**
 * @brief Resume a paused deferal.
 */
void
DEFERAL_CLASS::resume()
{
    if (state_.status == DEFERAL_PAUSED) {
	unsigned long now = TIMER_FN();
	dtime_.start_time = now - dtime_.remaining;
	state_.status = DEFERAL_RUNNING;
    }
}

/**
 * @brief Repeat the last delay from the time of its completion.
 *
 * If the added delay still leaves us stopped, we may run any
 * associated post Deferal function.  This only makes sense for
 * Deferals that have stopped.
 */
void
DEFERAL_CLASS::again(unsigned long delay, bool run_post_fn)
{
    if (state_.status == DEFERAL_STOPPED) {
	unsigned long now = TIMER_FN();
	unsigned long this_delay = delay? delay: delay_time_;
    
	// Set start_time_ to the time it would have automatically
	// restarted, had it done so.
	dtime_.start_time += delay_time_;
	delay_time_ = this_delay;
	while ((now - dtime_.start_time) > delay_time_) {
	    // Running again still leaves the finish time in the past
#ifdef DEFERAL_CALLBACK    
	    if (run_post_fn && defer_fn_) {
		state_.status = DEFERAL_PROCESSING;
		defer_fn_(defer_fn_param_);
		state_.status = DEFERAL_STOPPED;
	    }
#endif	    
	    if (!state_.autorepeat) {
		// If we are to autorepeat, we'll keep running the
		// loop until we caught up and then start ourselves
		// running again.  If not, we are done here.
		return;
	    }
	    dtime_.start_time += delay_time_;
	}
	state_.status = DEFERAL_RUNNING;
	addDeferalEntry(this);
    }
    else {
	start(delay);
    }
}

/**
 * @brief Return the outstanding delay amount at the current time.
 * Note that this may be negative if the delay has expired and not
 * restarted. 
 */
long
DEFERAL_CLASS::remaining()
{
    unsigned long now = TIMER_FN();
    return delay_time_ - (now - dtime_.start_time);
}

#ifdef DEFERAL_CALLBACK    
/**
 * @brief Set the function to be run when the Deferal expires.
 * 
 * @param fn  The function to be called on completion of our delay.
 * @param param  A parameter to be passed to the above function on
 * completion of our delay.
 */
void
DEFERAL_CLASS::setDeferalFn(PostDeferalFn fn, void *param)
{
    defer_fn_ = fn;
    defer_fn_param_ = param;
}
#endif

/**
 * @brief Return the delay period for this Deferal.
 */
long
DEFERAL_CLASS::delayPeriod()
{
    return delay_time_;
}

/**
 * @brief Set the delay period for this Deferal.
 *
 * @param delay  The delay for our deferred operation, based on the
 * units of Deferal::timer_fn_().  
 */
void
DEFERAL_CLASS::setDelay(unsigned long delay)
{
    delay_time_ = delay;
}

/**
 * @brief Set the offset period for the first expiry of this Deferal.
 *
 * This should be set immediately after creating the Deferal or
 * setting a delay.  This allows us to start a repeating delay with
 * the first delay expiring sooner or later than the delay period.
 * This allows us, for example, to set a heartbeat interval of one
 * minute, with the first heartbeat occurring 30 seconds from now.
 *
 * @param offset  The delay for the first expiry of this Deferal 
 * in units of Deferal::timer_fn_().  
 */
void
DEFERAL_CLASS::setOffset(unsigned long offset)
{
    unsigned long expiry_time = dtime_.start_time + delay_time_;
    dtime_.start_time = expiry_time - offset;
}


#ifdef UNIT_TESTING
/**
 * @brief Reset the deferal list to be empty.
 */
void
DEFERAL_CLASS::clearDeferals()
{
    deferal_list_ = NULL;
}

void
DEFERAL_CLASS::reset(unsigned long delay,
		     bool autorepeat,
		     bool start
#ifdef DEFERAL_TIMER_FN	    
		     , TimerFn timer_fn
#endif
		     )
{
    init(delay,
	 autorepeat,
	 start
#ifdef DEFERAL_TIMER_FN	    
	 , timer_fn
#endif
	 );
}
#endif    

