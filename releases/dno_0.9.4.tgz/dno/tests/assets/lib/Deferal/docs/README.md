# Deferal (V0.9.0) - Versatile Non blocking Delays and Deferred Execution Library

This library provides non-blocking objects for implementing delays.
Multiple delays may run concurrently, and they may be interleaved with
each other.  They also allow a callback function to be defined so that
asynchronous actions may be performed when delays expire.

## Basic Usage

    #include <Deferal.h>

You can use `Deferal` objects in three distinct ways:

### Simple Non-Blocking Delay

    delay = new Deferal(100);
    while (delay.running()) {
        // do some stuff while we wait
     }
     // do stuff at end of delay

This allows us to perform actions while we wait for our delay to
expire.

### Interleaved non-blocking delays

    delay1 = new Deferal(100);
    delay2 = new Deferal(207);
    while (true) {
        result = checkDeferals();
        if (result) {
            if (result == delay1) {
                // do something
            }
            if (result == delay2) {
                // do something else
            }
            result.again(); // Repeat the delay
        }
    }

The `checkDeferals()` call returns `NULL` if all delays are ongoing,
and returns the `Deferal` object for any delay that has completed.   It
does this once only for each completed delay, so if multiple delays
expire at the same time, it will return each of them on subsequent
calls.

Note the use of the `again()` member function.  This restarts the
delay from the expiry of the previous delay period.  This means that
`delay1` will expire at exactly 100 millisecond intervals from its
time of creation, regardless of how much time has passed between the
expiry of the period and the call of `again()`.

### Asynchronous Actions on Delay Completion

    delay = new Deferal(100, &my_do_func, &param_for_my_do_func);
    while (true) {
        // do your stuff
        checkDeferals();  // This will run my_do_func() when delay is done.
    }

This causes `my_do_func()` to be called with `param_for_my_do_func` as a
parameter, when the delay period expires.

A typical usage of this would be to turn off a LED after (say) 100
milliseconds, while allowing the `arduino` to do something useful in
the meantime.

## Ensuring Deferals Run and Expire

Deferals can only expire if you periodically call one of the functions
that checks them.  For a single Deferal, you can call
Deferal::running() or Deferal::stopped().  If you 
have multiple Deferals you should use Deferal::checkDeferals().  Your Deferals
will not expire unless one of these functions is called.

You must therefore be very careful if you use any blocking I/O
operations.

## Timer Functions

When you create a Deferal you may specify a timer function.  By
default this is the standard millis() function.

If you need greater precision you could use the micros() function, or
you can use your own function.

Note that this function does not have to be based on time, it could
return the number of times a loop has been executed, or the number of
characters read from a serial interface.

## Memory Footprint Management

`Deferal`s provide a lot of functionality, some of which you may not
need.  If you do not need callbacks or timer functions, they and
their associated storage, can each be conditionally compiled out.
Compiling for an `atmega328` this can reduce the memory footprint per
`Deferal` object from 17 to 11 bytes.

### Conditional Compilation Symbols

The Deferal library may be compiled with special symbols defined to
reduce the memory footprint of each Deferal object.

`Deferal`'s conditional compilation mechanisms are controlled by the
following symbols:

  - #DEFERAL_MINIMAL;

    Defining this allows conditional compilation for callback and
    timer function handling.  With this undefined, all Deferal
    functionality is automatically compiled in.  With it defined,
    callbacks and timer function functionality are disabled by
    default.

  - #DEFERAL_CALLBACK;

    With #DEFERAL_MINIMAL defined, defining this adds callback
    functionality.  With #DEFERAL_MINIMAL undefined, callback functionality
    is automatically enabled.  Callbacks are functions that a Deferal
    may automatically call when its expiry is detected.

  - #DEFERAL_TIMER_FN;

    With #DEFERAL_MINIMAL defined, defining this adds the ability to
    define timer functions.  
    functionality.  With #DEFERAL_MINIMAL undefined, Deferal timeouts
    all use the millis() function.

  - #DEFERAL_CLASS.
    Defining this causes the Deferal class to have a different name.
    This is primarily intended for users that are unable to provide
    values for the conditional compilation symbols through their build
    tool (IDE).  See the Conditional Compilation Howto below for more.

### Conditional Compilation Howto

### Using Make

If you use `make` for your build, you can simply define your conditional
compilation symbols using the -D option in your CFLAGS or CXXFLAGS
definition.  Adding something like the following to your `Makefile`
should work perfectly:

      DEFERAL_FLAGS := -D DEFERAL_MINIMAL -D DEFERAL_CALLBACK
      CXXFLAGS += $(DEFERAL_FLAGS)

### Using dno

If you use [dno](https://github.com/marcmunro/dno), you can create a
`dno.mk` file that contains:

      DEFERAL_FLAGS := -D DEFERAL_MINIMAL -D DEFERAL_CALLBACK
      CXXFLAGS += $(DEFERAL_FLAGS)

### With the Arduino IDE

If there is any way to provide symbol definitions through the standard
Arduino IDE, the Deferal library developer cannot find it.

But, if you need smaller Deferal objects and you are stuck with the
Arduino IDE, the following should work.

Create a header file, let's call it MyDeferal.h that contains the
following:

      #define DEFERAL_CLASS MyDeferal
      #include <Deferal.h>

Create a `cpp` file, MyDeferal.cpp, that contains this:

      #define DEFERAL_CLASS MyDeferal
      #include <Deferal.cpp>

And in any file where you want to use a Deferal, include `MyDeferal.h`
instead of Deferal.h, and use the name `MyDeferal` for the Deferal
class.  Eg:

      #include "MyDeferal.h"

      . . .

      static MyDeferal mytimer(500, true);

Doing this creates a renamed Deferal class called MyDeferal.  You need
this to prevent name clashes with the normal Deferal class, so the
link stage of the build will not attempt to reload the standard
Deferal library.

### Other IDEs

If your IDE allows you to pass custom flags to the compiler, something
like the technique for Make should work.  If not, you will be stuck
with the approach suggested for the Arduino IDE.

## Installation

Get it from github: https://github.com/marcmunro/Deferal.git

## Release Notes

### 0.9.0

First numbered release.
