% DNO_PROG(1) 0.9.4 | Dno Manual
% Marc Munro
% Future 2026

# NAME

dno_prog -  programmers.txt file parser for the dno Arduino build system.

# SYNOPSIS
 **dno_prog** [OPTIONS] {ARG]

# DESCRIPTION

Parses programmers.txt file to identify, list or extract definitions
for a programmer.

This is part of the dno Arduino software builder package.

# OPTIONS

**-c, --check**

Determine whether arg identifies a known programmer for the current
Arduino board type.  Returns success if so.

**-e, --extract**

Extract programmer details for the programmer given as arg.

**-h, --help**

Provide basic help.

**-l, --list**

List the available programmers for the current Arduino board type.

**-s, --show\***

In combination with -l, show the path to our programmers.txt file.

**-v, --version**

# SEE ALSO
  **dno**(1) **BOARD_INFO**(5) **BOARD_TYPE**(5)

# LICENSE

**dno_prog** is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, version 3 of the License.

**dno_prog** is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with dno. If not, see <https://www.gnu.org/licenses/>.

