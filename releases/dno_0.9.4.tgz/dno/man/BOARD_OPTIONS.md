% BOARD_OPTIONS(5)  0.9.4 | dno Configuration Files
% Marc Munro
% Future 2026

# NAME

BOARD_OPTIONS - file of Arduino menu options in make(1) syntax

# DESCRIPTION
BOARD_OPTIONS files are created and used by **dno**(1), or
**dno_menu**(1) to define selected build options for an Arduino
board.

The default options are determined from **BOARD_INFO**(5).  Running
**dno menu** or **dno_menu** allows the user to interactively select
desired options from the options available via a terminal-based menu
interface.  If the selected options are all left as default, then no
**BOARD_OPTIONS** file will be created, and any existing one will be
deleted.  If non-default options are selected, the selected options
will be recorded in the **BOARD_OPTIONS** file.

Note that the available options recorded in **BOARD_INFO** are
determined from the boards.txt file for the selected Arduino board.

FILES
boards.txt

# SEE ALSO
  **make**(1) **dno**(1) **dno_menu**(1) **dno_bpp** **BOARD_INFO**(5)

