% DNO_INO2C(1) 0.9.3 | Dno Manual
% Marc Munro
% June 2026

# NAME

dno_ino2c -  Convert .ino files to c++ output

# SYNOPSIS
 **dno_ino2c** [OPTIONS] [INPUT_FILE]...

# DESCRIPTION

Extracts the function prototypes for all INPUT-FILEs adding the
prototypes to the files, writing to stdout and including appropriate
line directives.

This is part of the dno Arduino software builder package.

# OPTIONS

**-h, --help**

Provide basic help.

**-v, --version**

Provide the version number.


# SEE ALSO
  **dno**(1)

# LICENSE

**dno_ino2c** is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, version 3 of the License.

**dno_ino2c** is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with dno. If not, see <https://www.gnu.org/licenses/>.

