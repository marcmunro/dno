% DNO_DIRINFO(1) 0.9.3 | Dno Manual
% Marc Munro
% June 2026

# NAME

dno_dirinfo - identify directory type for dno

# SYNOPSIS
 **dno_dirinfo** [OPTIONS] [directory-path]

# DESCRIPTION

**dno_dirinfo** identifies the type of directory for either the current
directory or the directory provided as a parameter.  The directory
type information is written to stdout as a string.

This is used by **dno** to determine the type of default build action
to be performed as well as setting up various build parameters.

In order to determine whether a directory is a board directory it may
to be able to verify whether the current directory's name is a match
for an Arduino board.  It does this using **dno_bpp** with the --dir
and --nodefaults options passed along.

# OPTIONS

**-d dir, --dir dir**

Pass this option to **dno_bpp** when determining whether our directory
is for an Arduino board.  See man **dno_bpp**(1) for more details.

**-h, --help**

Provide help.

**-n, --no, --nodefaults**

Pass this option to **dno_bpp** when determining whether our directory
is for an Arduino board.  See man **dno_bpp**(1) for more details.

**-v, --version**

print version information and exit


# DIRECTORY TYPES

The following types of directory are identified by **dno_dirinfo**:

  - docs

    A documentation directory.  **dno**'s default action in such a
    directory is to attempt to build documentation.

  - lib

    A library directory.  This directory appears to contain code for
    an Arduino library.  If it also contains a test, tests, or unit
    directory **dno**'s default action will be to compile and run any
    specified unit tests.

  - root

    This appears to be a project's root directory, but does not
    contain code.  **dno** is not able to do anything here.  Note that
    many non-dno directories may appear to **dno_dirinfo** to be root
    directories but since **dno** will not do anything here it tends
    not to matter.

  - root_board

    This appears to be a project's root directory, contains code, and
    a BOARD_TYPE.  **dno**'s default action will be to compile and
    build the code for the given BOARD_TYPE.
    
  - root_code

    This appears to be a project's root directory, contains code, but
    does not specify a BOARD_TYPE.  **dno** is not able to do anything
    here. 

  - sub_board

    This is a directory below the project root directory with either a
    BOARD_TYPE file, or with the directory named for a valid
    BOARD_TYPE.  **dno**'s default action will be to compile and
    build the code for the given type of board.

  - test

    This is a test directory.  It is assumed that it will contain code
    for running unit tests.  **dno**'s default action will be to compile and
    run any unit tests.

  - test_container

    This is named like a test directory but contains no test code.  We
    assume that it instead contains directories of test code.

  - unknown

    We cannot determine the directory type. 

This is part of the dno Arduino software builder package.

# EXIT STATUS

Returns success as long as nothing goes horribly wrong.

# SEE ALSO
  **dno**(1)  **dno_bpp(1)**  **BOARD_TYPE**(5) 

# LICENSE

**dno_dirinfo** is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, version 3 of the License.

**dno_dirinfo** is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with dno. If not, see <https://www.gnu.org/licenses/>.

